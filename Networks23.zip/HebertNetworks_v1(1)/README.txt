Run 'make client' or 'make server' to only compile one of them 
Run 'make' to compile both at once

Run 'hostname -I' on the terminal you plan on running the server to find the IP address.
If you recieve two addresses, choose the first one.

Run server with 'make runserver'
Run client with 'make runclient' on a separate terminal

random.txt holds the md5sum hash.