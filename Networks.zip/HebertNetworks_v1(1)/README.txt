Run 'make client' or 'make server' to only compile one of them 
Run 'make' to compile both at once

Run server with 'make runserver'
Run client with 'make runclient'

random.txt holds the md5sum hash.
