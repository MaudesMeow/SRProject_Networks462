#ifndef HKMSERVER_H
#define HKMSERVER_H


// int UserInputPromptPort();
// void UserInputPromptFile();
int CreateSocketServer(int port);


#endif